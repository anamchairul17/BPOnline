package com.anam.bponline

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class ParentActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_parent)
    }
}